import os, sys
from array import array

def save(fnam, num):

	f = open(fnam + '.fnt', "rb")
	buffer = f.read()
	f.close()

	out = open('assets\pic'+str(num)+'.fnt', "wb")
	out.write(buffer[0:9216])
	out.close()

	f = open(fnam + '.cmp', "rb")
	buffer = f.read()
	f.close()

	out = open('assets\pic'+str(num)+'.cmp', "wb")
	out.write(buffer[0:49920])
	out.close()

	f = open(fnam + '.scr', "rb")
	buffer = f.read()
	f.close()

	out = open('assets\pic'+str(num)+'.scr', "wb")
	out.write(buffer[0:1120])
	out.close()

	f = open(fnam + '.txt', "r")
	buffer = f.read()
	f.close()

	tit=fnam[3:fnam.find("\\",3,len(fnam))]

	out = open('assets\pic'+str(num)+'.dat', "w")
	out.write(tit)
	out.write('\n')
	out.write(buffer)
	out.write('\n')
	out.close()

	g = open('assets\pic'+str(num)+'.txt', "wb")

	f = open('assets\pic'+str(num)+'.dat', "r")

	s=f.readline()
	s=s[0:s.find("\\n")]
	while len(s) < 40:
		s=s+" "
	buf = bytearray(s,'ascii')
	g.write(buf);

	s=f.readline()
	s=s[0:s.find("\\n")]
	while len(s) < 40:
		s=s+" "
	buf = bytearray(s,'ascii')
	g.write(buf);

	s=f.readline()
	s=s[0:s.find("\\n")]
	while len(s) < 40:
		s=s+" "
	buf = bytearray(s,'ascii')
	g.write(buf);

	s=f.readline()
	s=s[0:s.find("\\n")]
	
	i=int(s)

	lst = [i]
	buf = bytearray(lst)
	g.write(buf);
	
	s=f.readline()
	s=s[0:s.find("\\n")]
	buf = bytearray(s,'ascii')
	g.write(buf);
		
	f.close
	g.close

	return


def main():
        save('..\DATASTORM 2012 C64 GRAPHICS COMPETITION\pic-3', 0)
        save('..\DATASTORM 2013 C64 GRAPHICS COMPETITION\pic-1', 1)
        save('..\DATASTORM 2013 C64 GRAPHICS COMPETITION\pic-2', 2)
        save('..\DATASTORM 2014 C64 GRAPHICS COMPETITION\pic-1', 3)
        save('..\DATASTORM 2017 C64 GRAPHICS COMPETITION\pic-1', 4)
        save('..\FOREVER 2016 C64 GRAPHICS COMPETITION\pic-1', 5)
        save('..\GUBBDATA 2015 C64 GRAPHICS COMPETITION\pic-2', 6)
        save('..\GUBBDATA 2016 C64 GRAPHICS COMPETITION\pic-3', 7)
        save('..\GUBBDATA 2018 C64 GRAPHICS COMPETITION\pic-2', 8)
        save('..\GUBBDATA 2019 C64 GRAPHICS COMPETITION\pic-2', 9)
        save('..\GUBBDATA 2020 C64 GRAPHICS COMPETITION\pic3', 10)


main()
