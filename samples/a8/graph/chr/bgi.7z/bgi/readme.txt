https://moddingwiki.shikadi.net/wiki/BGI_Stroked_Font


/*
Copyright 2024 CTPAX-X Team
This source code licensed under the Apache License, Version 2.0 (the "License"):
https://www.apache.org/licenses/LICENSE-2.0
*/

/* draws a character:
x, y - initial screen positon
b - buffer pointer to a Stroke Data for character */
void chr_draw_char(int x, int y, unsigned char *b) {
char m, dx, dy;
int xc, yc;
  /* initial position according to Stroke Header */
  y += origin_to_ascender - origin_to_descender;
  xc = x;
  yc = y;
  moveto(xc, yc);
  do {
    /* get mask */
    m = b[0] >> 7;
    m += m + (b[1] >> 7);
    /* 0 - stop; 1 - scan; 2 - move; 3 - draw */
    if (m > 1) {
      /* bit arithmetic (note dx/dy signed 8 bit type):
      if sign bit is set - expand to full signed value */
      dx = (b[0] & 0x7F) | ((b[0] & 0x40) << 1);
      dy = (b[1] & 0x7F) | ((b[1] & 0x40) << 1);
      dy = -dy;
      /* dx/dy relative to initial screen positon */
      xc = x + dx;
      yc = y + dy;
      if (m == 2) {
        moveto(xc, yc);
      } else {
        lineto(xc, yc);
      }
    }
    /* next byte pair */
    b += 2;
  } while (m);
}


