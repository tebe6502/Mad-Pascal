VOX REGIS -  atari 8 bit game

author: Wojciech Bociański
email: bocianu@gmail.com

game is written in MadPascal : http://mads.atari8.info/madpascal.html

